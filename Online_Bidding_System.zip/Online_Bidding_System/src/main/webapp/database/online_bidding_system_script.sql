create database online_bidding;
use online_bidding;

create table admin_signup
(
	admin_id int auto_increment primary key,
    full_name nvarchar(50),
    contact bigint(10),
    email nvarchar(50),
    login_id nvarchar(50),
    password nvarchar(50)
);

create table user_signup
(
	user_id int auto_increment primary key,
    full_name nvarchar(50),
    contact bigint(10),
    email nvarchar(50),
    login_id nvarchar(50),
    password nvarchar(50)
);

create table admin_add_product
(
	product_id int auto_increment primary key,
    product_name nvarchar(50),
    category nvarchar(50),
    company nvarchar(50),
    year nvarchar(50),
    base_price nvarchar(50),
    description nvarchar(50),
    image1 nvarchar(500),
    image2 nvarchar(500),
    image3 nvarchar(500) 
);

create table admin_add_category
(
	category_id int auto_increment primary key,
    category_name nvarchar(50),
    description nvarchar(500),
    image1 nvarchar(500) 
);

create table bidding_table
(
	bid_id int auto_increment primary key,
    product_id int,
    product_name nvarchar(50),
    category nvarchar(50),
    company nvarchar(50),
    year nvarchar(50),
    base_price nvarchar(50),
    user_id int,
    full_name nvarchar(50),
    amount nvarchar(50),
    bid_date nvarchar(50)
);


