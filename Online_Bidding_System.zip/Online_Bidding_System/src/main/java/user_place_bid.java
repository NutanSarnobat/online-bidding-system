

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection; 
import java.util.Date;
import java.sql.Statement;
import java.text.SimpleDateFormat;

/**
 * Servlet implementation class user_place_bid
 */
public class user_place_bid extends HttpServlet {
	
	Connection cn = null;
	Statement st = null;
	
	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			PrintWriter out = resp.getWriter();
			HttpSession session = req.getSession();
			
			Database db = new Database();
			String result = db.Connectdb();
			out.println(result);
			
			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			String bid_date = df.format(date);
					
			String amount = req.getParameter("amount");  
			
			String event = req.getParameter("submit");
			
			
			out.println(event);
			
			if(event.equals("Place Bid"))
			{
				if(amount.equals("")   )
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Please Enter Amount'); location='user_place_bid.jsp'; </script> ");
				}
				else
				{
					try
					{
						 String sql="insert into bidding_table ( product_id, product_name, category, company, year, base_price, user_id, full_name, amount, bid_date) values ('"+session.getAttribute("product_id")+"', '"+session.getAttribute("product_name")+"', '"+session.getAttribute("category")+"', '"+session.getAttribute("company")+"', '"+session.getAttribute("year")+"', '"+session.getAttribute("base_price")+"', '"+session.getAttribute("user_id")+"','"+session.getAttribute("full_name")+"','"+amount+"','"+bid_date+"') ";
						 String insert = db.Insert(sql);
						 out.println(insert);
						 
						 resp.setContentType("text/html");
						 out.println(" <script type=\"text/javascript\"> alert('Your Bid Has Been Placed'); location='user_place_bid.jsp'; </script> ");
						 
					}
					catch(Exception ex)
					{
						out.println(ex.toString());
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='user_place_bid.jsp'; </script> ");
					}
				}
			}    
		} 
}