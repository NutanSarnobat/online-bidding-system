

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Servlet implementation class user_my_bid
 */
public class user_my_bid extends HttpServlet {

	Connection cn = null;
	Statement st = null;
	
	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			PrintWriter out = resp.getWriter();
			HttpSession session = req.getSession();
			
			Database db = new Database();
			String result = db.Connectdb();
			out.println(result);
			
			Date date = new Date();
			SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyy");
			String today = df.format(date);
					
			String bid_id = req.getParameter("bid_id");  
			
			String event = req.getParameter("submit");
			
			
			out.println(event);
			
			if(event.equals("Revoke Bid"))
			{
				if(bid_id.equals("")   )
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Something went Wrong'); location='user_my_bids.jsp'; </script> ");
				}
				else
				{
					try
					{
						 String sql=" delete from bidding_table where bid_id = '"+bid_id+"' ";
						 String insert = db.delete(sql);
						 out.println(insert);
						 
						 resp.setContentType("text/html");
						 out.println(" <script type=\"text/javascript\"> alert('Your Bid Has Been Removed'); location='user_my_bids.jsp'; </script> ");
						 
					}
					catch(Exception ex)
					{
						out.println(ex.toString());
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='user_my_bids.jsp'; </script> ");
					}
				}
			}    
		} 
}