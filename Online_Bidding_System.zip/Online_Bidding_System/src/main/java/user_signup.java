

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

/**
 * Servlet implementation class user_signup
 */
public class user_signup extends HttpServlet {
	
	Connection cn = null;
	Statement st = null;
	
	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			PrintWriter out = resp.getWriter();
			HttpSession session = req.getSession();
			
			Database db = new Database();
			String result = db.Connectdb();
			out.println(result);
			
			String full_name = req.getParameter("full_name");
			String contact = req.getParameter("contact");
			String email = req.getParameter("email");
			String login_id = req.getParameter("login_id");
			String password = req.getParameter("password");
			String event = req.getParameter("submit");
			
			out.println(full_name);
			out.println(contact);
			out.println(email);
			out.println(login_id);
			out.println(password);
			out.println(event);
			
			if(event.equals("Signup"))
			{
				if(full_name.equals("") || contact.equals("") || email.equals("") || login_id.equals("") || password.equals(""))
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Somethinf is Empty'); location='user_signup.jsp'; </script> ");
				}
				else
				{
					try
					{
						String sql ="insert into user_signup (full_name, contact, email, login_id, password) values ('"+full_name+"', '"+contact+"', '"+email+"', '"+login_id+"', '"+password+"') ";
						String insert = db.Insert(sql);
						out.println(insert);
						
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('Signed Up Successfull.. Please Login now'); location='user_login.jsp'; </script> ");
					}
					catch(Exception ex)
					{
						out.println(ex.toString());
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='user_signup.jsp'; </script> ");
					}
				}
			}
			 
		}

}
