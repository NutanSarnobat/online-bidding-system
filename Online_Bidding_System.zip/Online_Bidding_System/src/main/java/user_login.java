

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Servlet implementation class user_login
 */
public class user_login extends HttpServlet {
	
	Connection cn = null;
	Statement st = null;
	
	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			PrintWriter out = resp.getWriter();
			HttpSession session = req.getSession();
			
			Database db = new Database();
			String result = db.Connectdb();
			out.println(result);
			 
			String login_id = req.getParameter("login_id");
			String password = req.getParameter("password");
			String event = req.getParameter("submit");
			 
			out.println(login_id);
			out.println(password);
			out.println(event);
			
			if(event.equals("Login"))
			{
				if(login_id.equals("") || password.equals("")  )
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Somethinf is Empty'); location='user_login.jsp'; </script> ");
				}
				else
				{
					try
					{
						Class.forName("com.mysql.jdbc.Driver");
						cn=DriverManager.getConnection("jdbc:mysql://localhost:3306/online_bidding","root","root");
						st=cn.createStatement();
						String sql="select * from user_signup where login_id ='"+login_id+"' && password = '"+password+"' ";
						ResultSet rs=st.executeQuery(sql);
						if(rs.next())
						{
							session.setAttribute("user_id", rs.getString("user_id"));
							session.setAttribute("full_name", rs.getString("full_name"));
							session.setAttribute("contact", rs.getString("contact"));
							session.setAttribute("email", rs.getString("email"));
							session.setAttribute("login_id", rs.getString("login_id")); 
							
							resp.setContentType("text/html");
							out.println(" <script type=\"text/javascript\"> alert('Logged in Successfull..'); location='user_home.jsp'; </script> ");
						}
						else
						{
							resp.setContentType("text/html");
							out.println(" <script type=\"text/javascript\"> alert('Login Failed.. Please try again'); location='user_login.jsp'; </script> ");
						}
 						
					}
					catch(Exception ex)
					{
						out.println(ex.toString());
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='user_login.jsp'; </script> ");
					}
				}
			}
			 
		
		}

}
