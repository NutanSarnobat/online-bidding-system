

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

/**
 * Servlet implementation class admin_add_category
 */
public class admin_add_category extends HttpServlet {
	
	Connection cn = null;
	Statement st = null;
	
	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			PrintWriter out = resp.getWriter();
			HttpSession session = req.getSession();
			
			Database db = new Database();
			String result = db.Connectdb();
			out.println(result);
			
			String category_id = req.getParameter("category_id");
			String category_name = req.getParameter("category_name");
			String description = req.getParameter("description"); 
			String image1 = req.getParameter("image1"); 
			String event = req.getParameter("submit");
			
			
			out.println(event);
			
			if(event.equals("ADD"))
			{
				if(category_id.equals("") || category_name.equals("") || description.equals("")  || image1.equals("") )
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Somethinf is Empty'); location='admin_add_category.jsp'; </script> ");
				}
				else
				{
					try
					{
						String sql ="insert into admin_add_category (category_name, description, image1 ) values ('"+category_name+"', '"+description+"', '"+image1+"' ) ";
						String insert = db.Insert(sql);
						out.println(insert);
						
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('Category Added'); location='admin_add_category.jsp'; </script> ");
					}
					catch(Exception ex)
					{
						out.println(ex.toString());
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='admin_add_category.jsp'; </script> ");
					}
				}
			}
			
			
			if(event.equals("UPDATE"))
			{
				if(category_id.equals("") || category_name.equals("") || description.equals("")  || image1.equals("") )
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Something is Empty'); location='admin_add_category.jsp'; </script> ");
				}
				else
				{
					try
					{
						String sql ="update admin_add_category set category_name =  '"+category_name+"', description = '"+description+"' , image1='"+image1+"'  where category_id ='"+category_id+"' ";																																																								  
						String update = db.update(sql);
						out.println(update);
						
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('Category Updated'); location='admin_add_category.jsp'; </script> ");
					}
					catch(Exception ex)
					{
						out.println(ex.toString());
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='admin_add_category.jsp'; </script> ");
					}
				}
			}
			
			
			if(event.equals("DELETE"))
			{
				if(category_id.equals("")  )
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Enter Category ID'); location='admin_add_category.jsp'; </script> ");
				}
				else
				{
					try
					{
						String sql ="delete from admin_add_category where category_id ='"+category_id+"' ";																																																								  
						String update = db.update(sql);
						out.println(update);
						
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('Category Deleted'); location='admin_add_category.jsp'; </script> ");
					}
					catch(Exception ex)
					{
						out.println(ex.toString());
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='admin_add_category.jsp'; </script> ");
					}
				}
			}
			 
		}

}
