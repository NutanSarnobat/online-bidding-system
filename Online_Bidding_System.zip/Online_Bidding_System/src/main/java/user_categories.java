

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

/**
 * Servlet implementation class user_categories
 */
public class user_categories extends HttpServlet {

	Connection cn = null;
	Statement st = null;
	
	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			PrintWriter out = resp.getWriter();
			HttpSession session = req.getSession();
			
			Database db = new Database();
			String result = db.Connectdb();
			out.println(result);
			 
			String category_name = req.getParameter("category_name"); 
			String event = req.getParameter("submit");
			
			
			out.println(event);
			
			if(event.equals("View"))
			{
				if(category_name.equals("")   )
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Somethinf is Empty'); location='user_categories.jsp'; </script> ");
				}
				else
				{
					try
					{
						 session.setAttribute("category_name", category_name);
						 resp.sendRedirect("user_products_bycategories.jsp");
						 
					}
					catch(Exception ex)
					{
						out.println(ex.toString());
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='user_categories.jsp'; </script> ");
					}
				}
			}    
		} 
}
