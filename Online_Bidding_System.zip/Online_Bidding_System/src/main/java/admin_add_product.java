

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Statement;

/**
 * Servlet implementation class admin_add_product
 */
public class admin_add_product extends HttpServlet {
	
	
	Connection cn = null;
	Statement st = null;
	
	@Override
		protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

			PrintWriter out = resp.getWriter();
			HttpSession session = req.getSession();
			
			Database db = new Database();
			String result = db.Connectdb();
			out.println(result);
			
			String product_id = req.getParameter("product_id");
			String product_name = req.getParameter("product_name");
			String category = req.getParameter("category");
			String company = req.getParameter("company");
			String year = req.getParameter("year");
			String base_price = req.getParameter("base_price");
			String description = req.getParameter("description");
			String image1 = req.getParameter("image1");
			String image2 = req.getParameter("image2");
			String image3 = req.getParameter("image3");
			String event = req.getParameter("submit");
			
			
			out.println(event);
			
			if(event.equals("ADD"))
			{
				if(product_id.equals("") || product_name.equals("") || category.equals("") || company.equals("") || year.equals("") || base_price.equals("") || description.equals("") )
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Somethinf is Empty'); location='admin_add_product.jsp'; </script> ");
				}
				else
				{
					try
					{
						String sql ="insert into admin_add_product (product_name, category, company, year, base_price, description, image1, image2, image3) values ('"+product_name+"', '"+category+"', '"+company+"', '"+year+"', '"+base_price+"', '"+description+"', '"+image1+"', '"+image2+"', '"+image3+"') ";
						String insert = db.Insert(sql);
						out.println(insert);
						
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('Product Added'); location='admin_add_product.jsp'; </script> ");
					}
					catch(Exception ex)
					{
						out.println(ex.toString());
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='admin_add_product.jsp'; </script> ");
					}
				}
			}
			
			
			if(event.equals("UPDATE"))
			{
				if(product_id.equals("") || product_name.equals("") || category.equals("") || company.equals("") || year.equals("") || base_price.equals("") || description.equals("") )
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Somethinf is Empty'); location='admin_add_product.jsp'; </script> ");
				}
				else
				{
					try
					{
						String sql ="update admin_add_product set product_name =  '"+product_name+"', category = '"+category+"' , company='"+company+"', year='"+year+"' , base_price='"+base_price+"', description='"+description+"', image1='"+image1+"', image2='"+image2+"', image3='"+image3+"' where product_id ='"+product_id+"' ";																																																								  
						String update = db.update(sql);
						out.println(update);
						
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('Product Updated'); location='admin_add_product.jsp'; </script> ");
					}
					catch(Exception ex)
					{
						out.println(ex.toString());
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='admin_add_product.jsp'; </script> ");
					}
				}
			}
			
			
			if(event.equals("DELETE"))
			{
				if(product_id.equals("")  )
				{
					resp.setContentType("text/html");
					out.println(" <script type=\"text/javascript\"> alert('Enter Product ID'); location='admin_add_product.jsp'; </script> ");
				}
				else
				{
					try
					{
						String sql ="delete from admin_add_product where product_id ='"+product_id+"' ";																																																								  
						String update = db.update(sql);
						out.println(update);
						
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('Product Updated'); location='admin_add_product.jsp'; </script> ");
					}
					catch(Exception ex)
					{
						out.println(ex.toString());
						resp.setContentType("text/html");
						out.println(" <script type=\"text/javascript\"> alert('"+ex.toString()+"'); location='admin_add_product.jsp'; </script> ");
					}
				}
			}
			 
		}

}
